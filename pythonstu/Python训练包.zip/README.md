# Python + Ollama 训练包

这是学习网页的配套材料。先解压，在 VS Code 选择自己的 Python 3.12 环境，然后从单题目录打开练习。

- drills/E01～E36：题面README、starter.py、reference.py、checks.py。
- projects/01～07：参考main.py、任务分关说明、小样例数据。项目04需要Python ollama包和已准备的本机服务与模型；其余要求写在各项目README。
- extension_lessons：10节拓展小课的讲解与参考代码。

建议流程：读README → 写starter.py → 把checks.py里的断言接到自己的实现之后运行 → 自己增加一个边界例子 → 最后对照reference.py。
checks.py不自动导入答案；它是一组供你复制或适配的验收语句。它只能覆盖部分约定，不代表完整证明。

练习E30用于理解__main__：导入模块时不应触发input，直接运行参考文件则会进入交互。
项目07默认模拟，只有显式--real并提供--model时才会发送模型请求。本包不会自动安装软件、下载模型或执行任何代码。
网页里的草稿和自评状态保存在浏览器，下载包不包含你的个人草稿；可另用页面“下载我的练习.py”导出。
