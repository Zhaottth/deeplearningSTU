def add(a, b):
    return a + b

# 错误位置：这行顶层交互在导入时也执行
name = input("姓名：")
