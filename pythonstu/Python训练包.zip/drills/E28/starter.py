def complete_turn(history, question, send):
    history.append({"role": "user", "content": question})
    answer = send(history)
    history.append({"role": "assistant", "content": answer})
    return history
