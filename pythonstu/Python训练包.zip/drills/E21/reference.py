def classify_failure(symptom):
    layers = {"command": "命令层", "connection": "服务层", "model": "模型层"}
    return layers.get(symptom, "未知")
