assert parse_model_name("qwen2.5:0.5b") == ("qwen2.5", "0.5b")
assert parse_model_name("my-tutor") == ("my-tutor", "latest")
assert parse_model_name("host:5000/team/model:q4") == ("host:5000/team/model", "q4")
