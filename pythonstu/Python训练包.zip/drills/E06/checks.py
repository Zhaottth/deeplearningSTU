assert shipping(98, False) == 8
assert shipping(98, True) == 4
assert shipping(99, True) == 0
assert shipping(100, False) == 0
