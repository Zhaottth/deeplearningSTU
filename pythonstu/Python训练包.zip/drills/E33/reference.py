def batches(items, size):
    if type(size) is not int or size <= 0:
        raise ValueError("size须为正整数")
    batch = []
    for value in items:
        batch.append(value)
        if len(batch) == size:
            yield batch
            batch = []
    if batch:
        yield batch
