# E02 终端、Python 文件，谁该接这条命令？

单元1 · 起步 · 改错

以下 starter 把三条文本分到错误位置。返回修正后的映射；不要实际安装包或启动服务。

## 验收边界

- 三个入口全部正确才通过
- 解释为什么在 >>> 后输入 pip 会报 SyntaxError

## 提示

- -m pip 是解释器启动模块的系统命令。
- /clear 由 Ollama 交互客户端解释，不能直接发给 PowerShell。

## 加练

再分类 python hello.py、import sys、/bye，自己增加三条断言。
