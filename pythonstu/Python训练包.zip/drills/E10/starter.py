def parse_tags(raw):
    return list(set(raw.lower().split(",")))
