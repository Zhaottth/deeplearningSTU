def run_question(question, send):
    return send([{"role": "user", "content": question}])

calls = []
def fake_send(messages):
    calls.append(messages)
    return "固定答案"

assert run_question("解释列表", fake_send) == "固定答案"
assert calls == [[{"role": "user", "content": "解释列表"}]]
