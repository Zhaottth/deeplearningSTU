def parse_minutes(text):
    pass
