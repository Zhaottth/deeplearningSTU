def environment_report():
    # TODO：只返回数据，不在函数里打印
    pass
