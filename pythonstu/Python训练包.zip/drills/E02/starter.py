def command_places():
    return {"python -m pip --version": "Python文件",
            "print(123)": "终端命令",
            "/clear": "PowerShell"}
