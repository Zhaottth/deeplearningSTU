assert top_k_words([" B ", "a", "b", "A", ""], 2) == [("a", 2), ("b", 2)]
assert top_k_words(["a"], 0) == []
assert top_k_words([], 3) == []
