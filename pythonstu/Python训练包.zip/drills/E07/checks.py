assert selected_sum(0) == 0
assert selected_sum(3) == 3
assert selected_sum(15) == 30
assert selected_sum(20) == 48
