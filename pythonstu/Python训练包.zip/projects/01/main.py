import random

answer = random.randint(1, 100)
for turn in range(1, 8):
    try:
        guess = int(input(f"第 {turn}/7 次，猜一个数："))
    except ValueError:
        print("这次请输入整数。")
        continue
    if guess == answer:
        print(f"猜中了！用了 {turn} 次。")
        break
    print("大了，再小一点。" if guess > answer else "小了，再大一点。")
else:
    print(f"七次用完，答案是 {answer}。")