import json
record = {"topic": "函数", "minutes": 25}
text = json.dumps(record, ensure_ascii=False)
restored = json.loads(text)
assert restored["minutes"] == 25
