import argparse
import json
from pathlib import Path
from time import perf_counter
from urllib.request import Request, urlopen

CASES = [
    {"id": "variable", "question": "用一句话解释Python变量，并提到名字。", "keywords": ["名字"]},
    {"id": "slice", "question": "Python切片的结束位置是否包含？用不包含回答。", "keywords": ["不包含"]},
]

def evaluate(cases, send):
    rows = []
    for case in cases:
        started = perf_counter()
        try:
            answer = send(case["question"])
            hit = all(word in answer for word in case["keywords"])
            rows.append({"id": case["id"], "status": "ok", "rule_hit": hit,
                         "seconds": perf_counter() - started, "answer": answer})
        except (OSError, TimeoutError, ValueError, KeyError) as error:
            rows.append({"id": case["id"], "status": "error", "rule_hit": False,
                         "seconds": perf_counter() - started, "error": str(error)})
    return rows

def local_sender(model):
    def send(question):
        payload = {"model": model, "messages": [{"role": "user", "content": question}],
                   "stream": False, "options": {"temperature": 0.2, "num_predict": 128}}
        request = Request("http://127.0.0.1:11434/api/chat",
                          data=json.dumps(payload).encode("utf-8"),
                          headers={"Content-Type": "application/json"}, method="POST")
        with urlopen(request, timeout=120) as response:
            data = json.load(response)
        return data["message"]["content"]
    return send

def fake_send(question):
    return "变量的名字指向对象。" if "变量" in question else "切片结束位置不包含。"

def main():
    parser = argparse.ArgumentParser(description="Ollama评测台架；默认仅模拟，不连接模型")
    parser.add_argument("--real", action="store_true", help="显式启用本机真实模型请求")
    parser.add_argument("--model", help="真实请求时所用的完整模型名")
    parser.add_argument("--output", default="evaluation.json")
    args = parser.parse_args()
    if args.real and not args.model:
        parser.error("--real需要同时提供--model")
    sender = local_sender(args.model) if args.real else fake_send
    rows = evaluate(CASES, sender)
    result = {"mode": "real" if args.real else "simulation", "model": args.model if args.real else None,
              "rule_hits": sum(row["rule_hit"] for row in rows), "total": len(rows), "rows": rows}
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"模式：{result['mode']}；规则命中：{result['rule_hits']}/{result['total']}")
    print("关键词命中只是自动规则检查，不等于事实准确率。")

if __name__ == "__main__":
    main()
