def mask_phone(text):
    pass
