import argparse
from collections import Counter
import math
from pathlib import Path
import re

def tokens(text):
    # 教学基线：英文词与中文单字，不是语义向量模型
    return re.findall(r"[a-z_][a-z_0-9]*|[\u4e00-\u9fff]", text.lower())

def cosine(left, right):
    a, b = Counter(tokens(left)), Counter(tokens(right))
    denominator = math.sqrt(sum(v * v for v in a.values()) * sum(v * v for v in b.values()))
    return sum(v * b.get(k, 0) for k, v in a.items()) / denominator if denominator else 0.0

def chunks(text, size=240, overlap=40):
    if size <= 0 or not 0 <= overlap < size:
        raise ValueError("要求size>0且0<=overlap<size")
    for start in range(0, len(text), size - overlap):
        body = text[start:start + size]
        if body.strip():
            yield start, body
        if start + size >= len(text):
            break

def search_notes(folder, query, top_k=3):
    if top_k <= 0 or not query.strip():
        raise ValueError("查询不能为空，top_k须为正")
    root = Path(folder)
    if not root.is_dir():
        raise ValueError("笔记目录不存在")
    matches = []
    for path in sorted(root.rglob("*.md")):
        text = path.read_text(encoding="utf-8")
        for start, body in chunks(text):
            score = cosine(query, body)
            if score > 0:
                matches.append({"source": str(path.relative_to(root)),
                                "offset": start, "text": body, "score": score})
    matches.sort(key=lambda row: (-row["score"], row["source"], row["offset"]))
    return matches[:top_k]

def main():
    parser = argparse.ArgumentParser(description="关键词笔记检索基线，不会调用模型")
    parser.add_argument("--folder", default="notes")
    parser.add_argument("--query", required=True)
    parser.add_argument("--top-k", type=int, default=3)
    args = parser.parse_args()
    for number, match in enumerate(search_notes(args.folder, args.query, args.top_k), 1):
        print(f"[R{number}] {match['source']} 字符位置{match['offset']} 得分{match['score']:.3f}")
        print(match["text"], "\n")

if __name__ == "__main__":
    main()
