def receipt(price_text, count_text):
    return float(price_text) * int(count_text)
