def parse_many(texts):
    result = {"valid": [], "errors": []}
    for line, text in enumerate(texts, 1):
        try:
            value = int(text)
            if value < 0:
                raise ValueError("不能为负")
        except ValueError as error:
            result["errors"].append({"line": line, "reason": str(error)})
        else:
            result["valid"].append(value)
    return result

assert parse_many(["0", "x"])["valid"] == [0]
