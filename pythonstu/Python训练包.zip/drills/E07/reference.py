def selected_sum(n):
    total = 0
    for value in range(1, n + 1):
        if value % 3 == 0 and value % 5 != 0:
            total += value
    return total
