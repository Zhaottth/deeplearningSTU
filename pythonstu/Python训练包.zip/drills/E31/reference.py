def parse_minutes(text):
    value = int(text.strip())
    if not 1 <= value <= 240:
        raise ValueError("范围应为1～240")
    return value
