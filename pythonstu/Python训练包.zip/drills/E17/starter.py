def collect(value, records=[]):
    records.append(value)
    return records
