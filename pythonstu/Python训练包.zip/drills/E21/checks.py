assert classify_failure("command") == "命令层"
assert classify_failure("connection") == "服务层"
assert classify_failure("model") == "模型层"
assert classify_failure("other") == "未知"
