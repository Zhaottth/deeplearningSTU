items = list(range(5))
assert page_items(items, 1, 2) == [0, 1]
assert page_items(items, 3, 2) == [4]
assert page_items(items, 4, 2) == []
assert page_items([], 1, 2) == []
for page, size in ((0, 2), (1, 0), (True, 2)):
    try:
        page_items(items, page, size)
    except ValueError:
        pass
    else:
        raise AssertionError("非法分页参数")
