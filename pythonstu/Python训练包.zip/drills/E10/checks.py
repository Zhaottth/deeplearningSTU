assert parse_tags(" Python,sql, PYTHON,, SQL , ai ") == ["python", "sql", "ai"]
assert parse_tags(" , , ") == []
assert parse_tags("B,a,b") == ["b", "a"]
