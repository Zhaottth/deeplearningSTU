def summarize(values):
    print(sum(values))
