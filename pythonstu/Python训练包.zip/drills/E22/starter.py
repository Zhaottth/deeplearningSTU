def parse_model_name(name):
    pass
