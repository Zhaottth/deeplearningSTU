assert login(["x", "ok"], "ok") == 2
assert login([], "ok") is None
assert login(["x", "y", "z", "ok"], "ok") is None
assert login(["ok"], "ok") == 1
