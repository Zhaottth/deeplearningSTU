def extract_text(data, kind):
    if kind == "chat":
        return data.get("message", {}).get("content", "")
    if kind == "generate":
        return data.get("response", "")
    raise ValueError("未知接口")
