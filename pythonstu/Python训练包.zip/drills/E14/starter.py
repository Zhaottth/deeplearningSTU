def attendance(expected, arrived):
    pass
