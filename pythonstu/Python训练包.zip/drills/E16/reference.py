def add_task(tasks, name):
    value = name.strip()
    if not value:
        raise ValueError("任务不能为空")
    return tasks + [value]
