report = environment_report()
assert report["executable"]
assert len(report["version"]) == 2
assert type(report["is_venv"]) is bool
