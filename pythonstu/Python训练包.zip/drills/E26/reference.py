import json
def join_chat_lines(lines):
    parts = []
    for line in lines:
        if not line.strip():
            continue
        chunk = json.loads(line)
        if "error" in chunk:
            raise RuntimeError(chunk["error"])
        parts.append(chunk.get("message", {}).get("content", ""))
    return "".join(parts)
