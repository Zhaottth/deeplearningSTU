def recent_history(history, pairs):
    if pairs < 0 or len(history) % 2:
        raise ValueError("需要非负组数和完整问答对")
    expected = ("user", "assistant")
    if any(item.get("role") != expected[i % 2] for i, item in enumerate(history)):
        raise ValueError("历史角色顺序无效")
    return history[-2 * pairs:] if pairs else []
