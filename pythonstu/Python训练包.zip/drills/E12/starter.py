def clone_grid(grid):
    return grid.copy()  # 请修正
