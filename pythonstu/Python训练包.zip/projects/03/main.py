LOG = "study_log.txt"

def load_totals(path):
    totals = {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) != 2:
                    continue
                topic, raw_minutes = parts
                try:
                    minutes = int(raw_minutes)
                except ValueError:
                    continue
                if topic.strip() and minutes > 0:
                    totals[topic] = totals.get(topic, 0) + minutes
    except FileNotFoundError:
        pass  # 第一次运行，还没有记录文件
    return totals

def save_record(path, topic, minutes):
    with open(path, "a", encoding="utf-8") as f:
        f.write(f"{topic}\t{minutes}\n")

while True:
    topic = input("刚学了什么？（输入 q 退出）").strip()
    if topic == "q":
        break
    if not topic or any(ch in topic for ch in "\t\r\n"):
        print("主题不能为空，也不能包含制表符或换行。")
        continue
    try:
        minutes = int(input("学了几分钟？"))
    except ValueError:
        print("分钟数请输入整数。")
        continue
    if minutes <= 0:
        print("先学一小会儿，再来记录吧。")
        continue
    save_record(LOG, topic, minutes)
    totals = load_totals(LOG)
    print(f"累计学习 {sum(totals.values())} 分钟。")
    ranked = sorted(totals.items(), key=lambda item: item[1], reverse=True)
    if ranked:
        print(f"最常学习：{ranked[0][0]}，共 {ranked[0][1]} 分钟。")