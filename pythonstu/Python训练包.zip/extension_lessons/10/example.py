from statistics import mean, median
minutes = [15, 20, 25, 30, 180]
print(mean(minutes))    # 54
print(median(minutes))  # 25
# 同一数据的均值和中位数回答的是不同问题。
