def reverse_lines(text):
    pass
