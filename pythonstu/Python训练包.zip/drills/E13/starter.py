def topic_totals(records):
    pass
