def tokens_per_second(count, duration_ns):
    if count < 0:
        raise ValueError("token 数不能为负")
    if duration_ns <= 0:
        return None
    return count / (duration_ns / 1_000_000_000)
