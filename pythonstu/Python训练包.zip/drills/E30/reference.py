def add(a, b):
    return a + b

def main():
    name = input("姓名：")
    print(name, add(2, 3))

if __name__ == "__main__":
    main()
