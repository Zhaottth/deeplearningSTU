old = ["复习"]
assert add_task(old, " 练习 ") == ["复习", "练习"]
assert old == ["复习"]
try:
    add_task(old, " ")
except ValueError:
    pass
else:
    raise AssertionError("空名称应拒绝")
