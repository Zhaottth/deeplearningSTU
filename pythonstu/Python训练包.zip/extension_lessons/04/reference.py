from timeit import repeat

def slow_unique(items):
    result = []
    for value in items:
        if value not in result:
            result.append(value)
    return result

def fast_unique(items):
    return list(dict.fromkeys(items))

data = [n % 200 for n in range(1000)]
assert slow_unique(data) == fast_unique(data)
if __name__ == "__main__":
    print(min(repeat(lambda: fast_unique(data), number=10, repeat=3)))
