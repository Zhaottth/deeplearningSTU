from collections import Counter
def top_k_words(words, k):
    if type(k) is not int or k < 0:
        raise ValueError("k须为非负整数")
    clean = [word.strip().lower() for word in words if word.strip()]
    return sorted(Counter(clean).items(), key=lambda x: (-x[1], x[0]))[:k]
