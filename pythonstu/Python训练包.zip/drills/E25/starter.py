def extract_text(data, kind):
    return data["response"]
