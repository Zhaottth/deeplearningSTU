# E01 找出正在运行的 Python

单元1 · 起步 · 排查

写 environment_report，返回解释器路径、版本前两段、是否为 venv。先解释每项的意义，再在 VS Code 当前环境中运行。

## 验收边界

- 不要把某个固定安装路径写成返回值
- 在 base 与 .venv 各运行一次，对比输出

## 提示

- 引入 sys；executable 说明谁在运行。
- 用 prefix 与 base_prefix 的比较判断是否为 venv，不检查提示符文本。

## 加练

增加 site.getsitepackages；用同一个解释器 -m pip --version 对照包管理位置。
