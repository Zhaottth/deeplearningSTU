parser = build_parser()
args = parser.parse_args(["--query", "函数"])
assert args.query == "函数" and args.top_k == 3
assert parser.parse_args(["--query", "A", "--top-k", "2"]).top_k == 2
try:
    positive_int("0")
except Exception as error:
    assert type(error).__name__ == "ArgumentTypeError"
else:
    raise AssertionError("零应拒绝")
