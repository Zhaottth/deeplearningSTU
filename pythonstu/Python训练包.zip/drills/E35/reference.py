from dataclasses import dataclass, field
@dataclass
class Notebook:
    title: str
    bookmarks: list[str] = field(default_factory=list)

    def add_bookmark(self, name):
        value = name.strip()
        if not value:
            raise ValueError("书签不能为空")
        if value not in self.bookmarks:
            self.bookmarks.append(value)
