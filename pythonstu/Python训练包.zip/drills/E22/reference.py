def parse_model_name(name):
    if ":" not in name:
        return name, "latest"
    base, tag = name.rsplit(":", 1)
    if not base or not tag:
        raise ValueError("名称和标签不能为空")
    return base, tag
