def collect(value, records=None):
    if records is None:
        records = []
    records.append(value)
    return records
