def parse_tags(raw):
    result = []
    seen = set()
    for part in raw.split(","):
        value = part.strip().lower()
        if value and value not in seen:
            result.append(value)
            seen.add(value)
    return result
