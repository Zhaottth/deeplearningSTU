from pathlib import Path
def build_data_path(script_file, name):
    return Path(script_file).resolve().parent / "data" / name
