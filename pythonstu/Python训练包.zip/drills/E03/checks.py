assert receipt("3.5", "4") == 14.0
assert receipt("0", "5") == 0.0
assert receipt("8", "0") == 0.0
