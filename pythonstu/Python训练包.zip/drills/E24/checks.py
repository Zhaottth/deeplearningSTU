assert build_options("study")["temperature"] == 0.2
assert build_options("ideas")["temperature"] == 0.8
a, b = build_options("study"), build_options("study")
a["num_ctx"] = 8192
assert b["num_ctx"] == 4096
