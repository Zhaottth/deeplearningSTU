def grade(score):
    pass
