assert count_nonblank(iter(["a\n", "\n", "  ", "b"])) == 2
assert count_nonblank(iter([])) == 0
