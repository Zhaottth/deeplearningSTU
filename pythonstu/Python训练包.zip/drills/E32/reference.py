def page_items(items, page, size):
    if type(page) is not int or type(size) is not int or page <= 0 or size <= 0:
        raise ValueError("page和size须为正整数")
    start = (page - 1) * size
    return items[start:start + size]
