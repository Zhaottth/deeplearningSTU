def add_task(tasks, name):
    pass
