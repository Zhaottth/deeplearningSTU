def selected_sum(n):
    total = 0
    # TODO
    return total
