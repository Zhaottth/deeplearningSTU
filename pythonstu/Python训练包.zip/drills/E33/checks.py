assert list(batches(iter(range(5)), 2)) == [[0, 1], [2, 3], [4]]
assert list(batches([], 2)) == []
result = list(batches(range(4), 2))
result[0].append(99)
assert result[1] == [2, 3]
try:
    list(batches([1], 0))
except ValueError:
    pass
else:
    raise AssertionError("无效size")
