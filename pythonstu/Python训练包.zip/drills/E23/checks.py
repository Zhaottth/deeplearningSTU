assert tokens_per_second(120, 6_000_000_000) == 20
assert tokens_per_second(0, 2_000_000_000) == 0
assert tokens_per_second(10, 0) is None
