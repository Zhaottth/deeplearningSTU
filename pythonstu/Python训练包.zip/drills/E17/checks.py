assert collect("a") == ["a"]
assert collect("b") == ["b"]
given = []
assert collect("x", given) is given
assert given == ["x"]
