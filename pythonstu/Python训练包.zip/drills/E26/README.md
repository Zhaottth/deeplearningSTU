# E26 NDJSON 是一行一行的 JSON

单元13 · 进阶 · 实现

join_chat_lines 接收流式行文本，忽略空行，按顺序拼接 message.content；遇到error字段抛 RuntimeError。

## 验收边界

- 空行、结束块无文本
- 不能整段当单一JSON解析

## 提示

- 每轮 json.loads 一行。
- 先检查错误，再提取可能为空的文本字段。

## 加练

做增量生成器逐块输出；与“收到全部行后拼接”的版本比较首字延迟。
