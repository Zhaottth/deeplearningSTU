def login(attempts, correct):
    for number, value in enumerate(attempts[:3], 1):
        if value == correct:
            return number
    return None
