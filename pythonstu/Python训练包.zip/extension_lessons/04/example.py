def unique_in_order(items):
    seen, result = set(), []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

assert unique_in_order([3, 1, 3, 2]) == [3, 1, 2]
