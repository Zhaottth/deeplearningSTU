assert extract_text({"message": {"content": "你好"}}, "chat") == "你好"
assert extract_text({"response": "你好"}, "generate") == "你好"
assert extract_text({}, "chat") == ""
