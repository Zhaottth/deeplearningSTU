assert split_seconds(0) == (0, 0, 0)
assert split_seconds(59) == (0, 0, 59)
assert split_seconds(3661) == (1, 1, 1)
assert split_seconds(90000) == (25, 0, 0)
