from statistics import median
def summarize_week(daily_minutes):
    values = [x for x in daily_minutes if x is not None]
    return {"total": sum(values), "recorded_days": len(values),
            "median": median(values) if values else None,
            "missing_days": sum(x is None for x in daily_minutes)}

assert summarize_week([0, 20, None])["recorded_days"] == 2
assert summarize_week([None])["median"] is None
