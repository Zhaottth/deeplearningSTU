def complete_turn(history, question, send):
    pending = history + [{"role": "user", "content": question}]
    answer = send(pending)
    return pending + [{"role": "assistant", "content": answer}]

old = []
def fail(messages):
    raise TimeoutError("等待超时")
try:
    complete_turn(old, "问", fail)
except TimeoutError:
    pass
else:
    raise AssertionError("必须传播超时")
assert old == []
