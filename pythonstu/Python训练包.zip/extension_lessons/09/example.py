def build_context(hits):
    return "\n\n".join(
        f"[R{number}] 来源：{item['source']}\n{item['text']}"
        for number, item in enumerate(hits, 1)
    )

hits = [{"source": "functions.md", "text": "return向调用者返回结果。"}]
assert "[R1]" in build_context(hits)
