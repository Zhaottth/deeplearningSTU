def topic_totals(records):
    totals = {}
    for topic, minutes in records:
        name = topic.strip()
        if name and minutes > 0:
            totals[name] = totals.get(name, 0) + minutes
    return totals
