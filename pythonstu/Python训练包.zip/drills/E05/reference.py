import math
def grade(score):
    if type(score) not in (int, float) or not math.isfinite(score) or not 0 <= score <= 100:
        raise ValueError("无效分数")
    if score >= 90:
        return "优秀"
    if score >= 60:
        return "通过"
    return "补考"
