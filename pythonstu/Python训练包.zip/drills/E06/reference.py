def shipping(total, member=False):
    if total < 0:
        raise ValueError("金额不能为负")
    if total >= 99:
        return 0
    return 4 if member else 8
