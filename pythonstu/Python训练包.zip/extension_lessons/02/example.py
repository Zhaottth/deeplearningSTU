def parse_row(text):
    value = int(text)
    if value < 0:
        raise ValueError("不能为负")
    return value

valid, errors = [], []
for index, text in enumerate(["3", "bad", "-1", "0"], 1):
    try:
        valid.append(parse_row(text))
    except ValueError as error:
        errors.append((index, str(error)))
assert valid == [3, 0]
