# E35 每本学习册都有自己的书签

单元18 · 应用 · 实现

用 dataclass 实现 Notebook(title, bookmarks)，提供 add_bookmark。新增书签清理空格、拒绝空值，并防止重复；实例间不能共享书签列表。

## 验收边界

- 两个实例的独立性
- 重复、空白名称

## 提示

- 默认列表用field(default_factory=list)。
- self.bookmarks属于当前实例。

## 加练

导出成JSON后再恢复；决定重复书签是忽略、报错还是更新时间。
