assert mask_phone(" 13812345678 ") == "138****5678"
for bad in ("123", "13812a45678", "１３８１２３４５６７８"):
    try:
        mask_phone(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("无效输入未被拒绝")
