def clone_grid(grid):
    return [row.copy() for row in grid]
