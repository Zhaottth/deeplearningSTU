def parse_item(name, price_text, count_text):
    price, count = float(price_text), int(count_text)
    if not name.strip() or price < 0 or count < 0:
        raise ValueError("商品数据无效")
    return {"name": name.strip(), "price": price, "count": count}

def calculate_total(items):
    return sum(item["price"] * item["count"] for item in items)

def format_receipt(items):
    return f"共{len(items)}项，合计{calculate_total(items):.2f}元"

assert format_receipt([parse_item("笔", "2.5", "4")]) == "共1项，合计10.00元"
