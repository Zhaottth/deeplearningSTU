from dataclasses import dataclass, field

@dataclass
class StudyLog:
    entries: list[int] = field(default_factory=list)

    def add(self, minutes):
        if type(minutes) is not int or minutes <= 0:
            raise ValueError("分钟数无效")
        self.entries.append(minutes)

    def total(self):
        return sum(self.entries)

a, b = StudyLog(), StudyLog()
a.add(20)
assert a.total() == 20 and b.total() == 0
