函数接收参数，通过return返回值。print用于展示，不代替return。空输入的行为需要事先约定。
