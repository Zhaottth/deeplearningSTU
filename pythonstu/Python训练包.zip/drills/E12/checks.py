source = [[1, 2], [3, 4]]
copied = clone_grid(source)
copied[0][0] = 99
assert source == [[1, 2], [3, 4]]
assert clone_grid([]) == []
assert clone_grid([[], []]) == [[], []]
