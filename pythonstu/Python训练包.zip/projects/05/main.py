import argparse
import csv
import json
import math
from pathlib import Path

def analyze_scores(path):
    valid, errors = [], []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        if not {"name", "class", "score"}.issubset(reader.fieldnames or []):
            raise ValueError("CSV需要name,class,score三列")
        for line_number, row in enumerate(reader, 2):
            try:
                name = (row.get("name") or "").strip()
                group = (row.get("class") or "").strip()
                score = float(row.get("score") or "")
                if not name or not group or not math.isfinite(score) or not 0 <= score <= 100:
                    raise ValueError("姓名、班级或分数无效")
                valid.append({"name": name, "class": group, "score": score})
            except (TypeError, ValueError) as error:
                errors.append({"line": line_number, "reason": str(error)})
    groups = {}
    for item in valid:
        groups.setdefault(item["class"], []).append(item["score"])
    report = {}
    for group, scores in sorted(groups.items()):
        report[group] = {
            "count": len(scores),
            "average": round(sum(scores) / len(scores), 2),
            "pass_rate": round(sum(x >= 60 for x in scores) / len(scores), 4),
        }
    ranked = sorted(valid, key=lambda item: (-item["score"], item["name"]))
    return {"groups": report, "ranked": ranked, "errors": errors}

def main():
    parser = argparse.ArgumentParser(description="课程成绩分析器")
    parser.add_argument("--input", default="scores.csv")
    parser.add_argument("--output", default="score_report.json")
    args = parser.parse_args()
    result = analyze_scores(args.input)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"有效{len(result['ranked'])}行；无效{len(result['errors'])}行；报告：{args.output}")

if __name__ == "__main__":
    main()
