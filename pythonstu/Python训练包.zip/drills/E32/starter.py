def page_items(items, page, size):
    pass
