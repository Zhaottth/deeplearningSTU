original = [-2, -1, 0, 3, -4]
assert keep_nonnegative(original) == [0, 3]
assert original == [-2, -1, 0, 3, -4]
assert keep_nonnegative([]) == []
