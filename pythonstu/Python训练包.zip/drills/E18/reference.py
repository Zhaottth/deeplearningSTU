def rank_students(students):
    return sorted(students, key=lambda item: (-item["score"], item["name"]))
