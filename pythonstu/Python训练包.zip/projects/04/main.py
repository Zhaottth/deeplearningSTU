from ollama import Client, ResponseError
import httpx

MODEL = "qwen2.5:0.5b"  # 先 pull，或改为 list 中已下载的完整名称
SYSTEM = {"role": "system", "content": "你是耐心的 Python 入门老师。用中文解释。"}
client = Client(host="http://127.0.0.1:11434", timeout=120.0)
history = []  # 只保存成功的 user / assistant 问答

while True:
    question = input("你（/clear 清空，/bye 退出）：").strip()
    if question == "/bye":
        break
    if question == "/clear":
        history.clear()
        print("本次对话历史已清空，模型文件保留。")
        continue
    if not question:
        continue
    # 最多保留最近 6 组完整问答；仍需注意单条消息的长度
    recent = history[-12:]
    user_message = {"role": "user", "content": question}
    request_messages = [SYSTEM] + recent + [user_message]
    chunks = []
    try:
        print("老师：", end="", flush=True)
        stream = client.chat(model=MODEL, messages=request_messages, stream=True)
        for chunk in stream:
            text = chunk.message.content or ""
            print(text, end="", flush=True)
            chunks.append(text)
        print()
    except ResponseError as error:
        print(f"\n服务返回错误 {error.status_code}：{error.error}；本轮未加入历史。")
        continue
    except httpx.TimeoutException:
        print("\n等待超时。检查模型加载和任务长度；本轮未加入历史。")
        continue
    except (ConnectionError, httpx.RequestError) as error:
        print(f"\n连接失败：{error}；先检查 Ollama 是否启动。本轮未加入历史。")
        continue
    answer = "".join(chunks)
    history = recent + [user_message, {"role": "assistant", "content": answer}]
