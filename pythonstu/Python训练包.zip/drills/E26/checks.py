lines = ["", '{"message":{"content":"你"}}', '{"message":{"content":"好"},"done":false}', '{"done":true}']
assert join_chat_lines(lines) == "你好"
try:
    join_chat_lines(['{"error":"模型失败"}'])
except RuntimeError:
    pass
else:
    raise AssertionError("流中错误应传播")
