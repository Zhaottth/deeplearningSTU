def mask_phone(text):
    phone = text.strip()
    if len(phone) != 11 or not phone.isascii() or not phone.isdigit():
        raise ValueError("需要11位ASCII数字")
    return phone[:3] + "****" + phone[-4:]
