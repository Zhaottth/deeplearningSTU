def reverse_lines(text):
    result = []
    for line in text.splitlines(keepends=True):
        newline = "\n" if line.endswith("\n") else ""
        body = line[:-1] if newline else line
        result.append(body[::-1] + newline)
    return "".join(result)
