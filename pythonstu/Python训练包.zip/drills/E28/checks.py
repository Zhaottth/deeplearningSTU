old = []
assert complete_turn(old, "你好", lambda messages: "回答")[-1]["content"] == "回答"
assert old == []
def fail(messages):
    raise ConnectionError("断开")
try:
    complete_turn(old, "问题", fail)
except ConnectionError:
    pass
else:
    raise AssertionError("异常应交给调用方")
assert old == []
