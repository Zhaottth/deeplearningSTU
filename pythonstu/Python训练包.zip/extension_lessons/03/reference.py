def nonblank_numbered(lines):
    for number, line in enumerate(lines, 1):
        text = line.strip()
        if text:
            yield number, text

assert list(nonblank_numbered(iter(["a", " ", "b"]))) == [(1, "a"), (3, "b")]
