def clean_lines(lines):
    for line in lines:
        text = line.strip()
        if text:
            yield text

source = iter([" a ", " ", "b"])
values = clean_lines(source)
assert next(values) == "a"
assert list(values) == ["b"]
