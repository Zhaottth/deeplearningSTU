def command_places():
    return {"python -m pip --version": "PowerShell",
            "print(123)": "Python文件",
            "/clear": "Ollama对话"}
