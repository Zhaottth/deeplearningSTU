def recent_history(history, pairs):
    pass
