def classify_failure(symptom):
    pass
