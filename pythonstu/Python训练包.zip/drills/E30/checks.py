assert add(2, 3) == 5
assert callable(main)
