assert topic_totals([(" 函数 ", 25), ("函数", 10), ("切片", 0), ("", 5)]) == {"函数": 35}
assert topic_totals([]) == {}
assert topic_totals([("A", -1), ("B", 2)]) == {"B": 2}
