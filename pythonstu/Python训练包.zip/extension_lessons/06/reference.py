from dataclasses import dataclass, field
@dataclass
class StudyLog:
    entries: list[int] = field(default_factory=list)

    def remove_last(self):
        if not self.entries:
            raise ValueError("没有可移除的记录")
        return self.entries.pop()

log = StudyLog([10, 20])
assert log.remove_last() == 20 and log.entries == [10]
