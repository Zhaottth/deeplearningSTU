def complete_turn(history, question, send):
    pending = history + [{"role": "user", "content": question}]
    answer = send(pending)
    return pending + [{"role": "assistant", "content": answer}]
