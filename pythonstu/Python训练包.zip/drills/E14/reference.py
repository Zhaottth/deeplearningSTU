def attendance(expected, arrived):
    expected_set = set(expected)
    arrived_set = set(arrived)
    return {"missing": expected_set - arrived_set,
            "unexpected": arrived_set - expected_set}
