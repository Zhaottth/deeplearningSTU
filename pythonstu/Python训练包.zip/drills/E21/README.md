# E21 把 Ollama 的三层故障分开

单元11 · 起步 · 排查

classify_failure 接收现象关键字：command、connection、model，分别返回命令层、服务层、模型层；其他值返回未知。

## 验收边界

- 这是排查思路练习，真实错误还要结合正文
- 给每层说出一条验证命令

## 提示

- 不要把所有失败都归到 Python 包。
- 分别联系 --version、/api/version、list。

## 加练

将规则扩展成返回排查清单，但避免仅凭HTTP状态码判定唯一原因。
