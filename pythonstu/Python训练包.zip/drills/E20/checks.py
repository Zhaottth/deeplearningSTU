assert reverse_lines("abc\n\n中文") == "cba\n\n文中"
assert reverse_lines("") == ""
assert reverse_lines("abc\n") == "cba\n"
