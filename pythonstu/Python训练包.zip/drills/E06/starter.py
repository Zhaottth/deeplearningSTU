def shipping(total, member=False):
    pass
