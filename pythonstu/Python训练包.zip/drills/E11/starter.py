def keep_nonnegative(values):
    for value in values:
        if value < 0:
            values.remove(value)
    return values
