def validate_record(data):
    if not isinstance(data, dict):
        raise ValueError("需要对象")
    topic, minutes = data.get("topic"), data.get("minutes")
    if not isinstance(topic, str) or not topic.strip():
        raise ValueError("主题无效")
    if type(minutes) is not int or minutes <= 0:
        raise ValueError("分钟数无效")
    return {"topic": topic.strip(), "minutes": minutes}

assert validate_record({"topic": " 函数 ", "minutes": 25}) == {"topic": "函数", "minutes": 25}
