a, b = Notebook("Python"), Notebook("Ollama")
a.add_bookmark(" 函数 ")
a.add_bookmark("函数")
assert a.bookmarks == ["函数"]
assert b.bookmarks == []
