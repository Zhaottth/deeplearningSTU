history = [{"role": role, "content": str(n)} for n in range(3) for role in ("user", "assistant")]
assert len(recent_history(history, 2)) == 4
assert recent_history(history, 0) == []
assert history[0]["content"] == "0"
try:
    recent_history(history[:-1], 2)
except ValueError:
    pass
else:
    raise AssertionError("半轮历史应拒绝")
