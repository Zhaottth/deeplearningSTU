from pathlib import Path
script = Path.cwd() / "demo" / "main.py"
assert build_data_path(script, "a.json") == script.parent / "data" / "a.json"
