assert parse_minutes(" 25 ") == 25
assert parse_minutes("1") == 1
assert parse_minutes("240") == 240
for bad in ("", "3.5", "abc", "0", "241"):
    try:
        parse_minutes(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("应拒绝: " + bad)
