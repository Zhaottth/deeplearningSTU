def receipt(price_text, count_text):
    return price_text * int(count_text)
