cases = [
    {"id": "slice", "question": '"Python"[1:4]是什么？', "expected": "yth"},
    {"id": "empty", "question": "空列表平均值应如何设计？", "rubric": "说明约定且避免除零"},
    {"id": "unknown", "question": "未提供的私有课程明天讲什么？", "rubric": "说明信息不足，不编造"},
]
assert len({case["id"] for case in cases}) == len(cases)
