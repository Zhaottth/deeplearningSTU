import sys
def environment_report():
    return {"executable": sys.executable,
            "version": tuple(sys.version_info[:2]),
            "is_venv": sys.prefix != sys.base_prefix}
