assert grade(0) == "补考"
assert grade(59.9) == "补考"
assert grade(60) == "通过"
assert grade(89.9) == "通过"
assert grade(90) == "优秀"
for bad in (-1, 101, True, float("nan")):
    try:
        grade(bad)
    except ValueError:
        pass
    else:
        raise AssertionError("应拒绝无效分数")
