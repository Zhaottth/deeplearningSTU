import argparse
def positive_int(text):
    try:
        number = int(text)
    except ValueError as error:
        raise argparse.ArgumentTypeError("需要整数") from error
    if number <= 0:
        raise argparse.ArgumentTypeError("需要正整数")
    return number

def build_parser():
    parser = argparse.ArgumentParser(description="笔记检索器")
    parser.add_argument("--query", required=True)
    parser.add_argument("--top-k", type=positive_int, default=3)
    return parser
