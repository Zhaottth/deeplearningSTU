def build_options(mode):
    temperatures = {"study": 0.2, "ideas": 0.8}
    if mode not in temperatures:
        raise ValueError("未知模式")
    return {"temperature": temperatures[mode], "num_ctx": 4096, "num_predict": 256}
