def tokens_per_second(count, duration_ns):
    pass
