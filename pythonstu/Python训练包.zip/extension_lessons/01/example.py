def calculate_total(prices):
    return sum(prices)

def build_message(total):
    return f"合计：{total:.2f} 元"

assert build_message(calculate_total([3, 4])) == "合计：7.00 元"
