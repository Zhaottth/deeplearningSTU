places = command_places()
assert places["python -m pip --version"] == "PowerShell"
assert places["print(123)"] == "Python文件"
assert places["/clear"] == "Ollama对话"
