assert attendance(["林", "周"], ["林", "李", "林"]) == {"missing": {"周"}, "unexpected": {"李"}}
assert attendance([], []) == {"missing": set(), "unexpected": set()}
