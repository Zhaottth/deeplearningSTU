items = [{"name": "b", "score": 90}, {"name": "a", "score": 90}, {"name": "c", "score": 95}]
assert [x["name"] for x in rank_students(items)] == ["c", "a", "b"]
assert [x["name"] for x in items] == ["b", "a", "c"]
assert rank_students([]) == []
