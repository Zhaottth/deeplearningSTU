def top_k_words(words, k):
    pass
