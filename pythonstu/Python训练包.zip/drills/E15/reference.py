def summarize(values):
    total = sum(values)
    return {"count": len(values), "total": total,
            "average": total / len(values) if values else None}
