def build_experiment(model, temperature):
    return {"model": model, "options": {"temperature": temperature,
            "num_ctx": 4096, "num_predict": 128}, "stream": False}

a = build_experiment("你已下载的模型名", 0.2)
b = build_experiment("你已下载的模型名", 0.8)
assert a["options"]["num_ctx"] == b["options"]["num_ctx"]
