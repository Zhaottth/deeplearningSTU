assert summarize([2, 4]) == {"count": 2, "total": 6, "average": 3}
assert summarize([]) == {"count": 0, "total": 0, "average": None}
assert summarize([0])["average"] == 0
