def show_contact(contacts, name):
    print(contacts.get(name, "还没有这位联系人。"))

contacts = {}
while True:
    action = input("1 新增/更新 | 2 查询 | 3 删除 | q 退出：").strip()
    if action == "q":
        break
    if action not in ("1", "2", "3"):
        print("请选择菜单中的操作。")
        continue
    name = input("姓名：").strip()
    if not name:
        print("姓名不能为空。")
        continue
    if action == "1":
        phone = input("电话：").strip()
        if not phone:
            print("电话不能为空。")
            continue
        contacts[name] = phone
        print("已保存。")
    elif action == "2":
        show_contact(contacts, name)
    else:
        removed = contacts.pop(name, None)
        print("已删除。" if removed is not None else "没有这位联系人。")