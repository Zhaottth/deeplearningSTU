def count_nonblank(lines):
    pass
