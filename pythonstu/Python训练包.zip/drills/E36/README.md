# E36 让检索器接受 --top-k

单元18 · 进阶 · 实现

build_parser 返回 argparse 解析器，支持 --query（必填）与 --top-k（默认3且须正整数）。函数本身不能立即读取真实命令行。

## 验收边界

- 提供参数列表即可测试
- 缺少必填项由argparse报告

## 提示

- 返回parser，主入口再调用parse_args。
- 将正整数约束封装为自定义type。

## 加练

增加 --verbose 配置日志，并用中文help解释哪些参数会触发真实模型调用。
