def build_data_path(script_file, name):
    pass
