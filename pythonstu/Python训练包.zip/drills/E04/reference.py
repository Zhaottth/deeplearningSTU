def split_seconds(total):
    if type(total) is not int or total < 0:
        raise ValueError("需要非负整数")
    hours = total // 3600
    rest = total % 3600
    return hours, rest // 60, rest % 60
