def join_chat_lines(lines):
    pass
