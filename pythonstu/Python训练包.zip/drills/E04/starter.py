def split_seconds(total):
    # TODO
    pass
