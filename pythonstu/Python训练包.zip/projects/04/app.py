import streamlit as st
import httpx
from ollama import Client, ResponseError

MODEL = "qwen2.5:0.5b"  # 与实际下载的标签保持一致
SYSTEM = {"role": "system", "content": "你是耐心的 Python 入门老师。用中文回答。"}
client = Client(host="http://127.0.0.1:11434", timeout=120.0)

st.title("今天学会一点 Python")
st.caption(f"本机 Ollama · {MODEL}")
if "messages" not in st.session_state:
    st.session_state.messages = []
if st.button("清空本次聊天"):
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])

prompt = st.chat_input("问一个 Python 问题")
if prompt and prompt.strip():
    user_message = {"role": "user", "content": prompt.strip()}
    recent = st.session_state.messages[-12:]
    with st.chat_message("user"):
        st.write(prompt.strip())
    try:
        with st.spinner("正在等待本地模型……"):
            response = client.chat(
                model=MODEL,
                messages=[SYSTEM] + recent + [user_message],
                stream=False,
            )
    except ResponseError as error:
        st.error(f"服务错误 {error.status_code}：{error.error}")
    except httpx.TimeoutException:
        st.error("等待超时，请检查模型加载与任务长度。")
    except (ConnectionError, httpx.RequestError) as error:
        st.error(f"连接失败，请检查 Ollama 服务：{error}")
    else:
        assistant_message = {"role": "assistant", "content": response.message.content or ""}
        st.session_state.messages = recent + [user_message, assistant_message]
        with st.chat_message("assistant"):
            st.write(assistant_message["content"])
