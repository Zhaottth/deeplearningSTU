def rank_students(students):
    pass
